CA-Clipper Update
Version 5.3
Release Notes
October 1995


This update to CA-Clipper 5.3 fixes real-mode indexing problems experienced
with the release version of CA-Clipper 5.3.

To use this update, simply include the object file, SORTOF.OBJ, (we know, we
know, but that's what it's called) in your link script and re-link your
application.  If you are building your application from the CA-Clipper
Workbench, simply add the file SORTOF.OBJ to the editbox labeled "Additional
.OBJ Files" in the linker options dialog box of your application.  No other
changes are necessary.

For example, if your current command for linking is:

   BLINKER FI MyFile LI MyLibs

Change this to:

   BLINKER FI MyFile, Sortof LI MyLibs


All product names referenced herein are trademarks of their respective
companies.

Copyright (c) 1995 Computer Associates International, Inc.  One Computer
Associates Plaza, Islandia, NY 11788-7000

