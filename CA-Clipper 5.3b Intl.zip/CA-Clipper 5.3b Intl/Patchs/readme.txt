CA-Visual Objects
Release 2.5 Trial Version
Release Notes

May 1999

___________________________________________________________________________

This file contains important information about CA-Visual Objects Release 2.5 Trial version.
 
Using WordPad to View This Document

If you enlarge the WordPad window to its maximum size, this document will be easier to read.  To do so, click the Maximize button in the upper right-hand corner of the window.  Or, click on the system menu in the upper left-hand corner of the WordPad window (or press Alt+Spacebar), and then choose the Maximize command.

To move through the document, press Page Up or Page Down or click the arrow at the top or bottom of the scroll bar along the right side of the WordPad window.

To print the document, choose the Print command from the File menu.

For help using WordPad, press F1.

To read other on-line documents, choose the Open command from the File menu.

___________________________________________________________________________

Contents

This document contains information on the following topics:

* Read Me First!
* Installation Notes
* Using Jasmine with CA-Visual Objects 2.5
* Trial Version Limitations
* New Features and Improvements
* Nations Modules
* CompuServe Facilities
* Operating Systems
* Ordering Information
* Acknowledgments
___________________________________________________________________________

Read Me First!

Repository Backup

If you do not follow this procedure, your applications and libraries will be lost, with no chance of recovery.

Before installing a new version or build of CA-Visual Objects or re-installing the repository of an existing version, you must export all applications and libraries (yours, not the system's) that you wish to save.  Installing the repository creates a new repository containing only the CA-Visual Objects system libraries.  After the installation is complete, you can import your applications and libraries back into the newly created repository.  

___________________________________________________________________________

Installation Notes

This section contains important information that you may need to properly install the CA-Visual Objects 2.5 Trial version.

Installing CA-Visual Objects 2.5 on a system that has CA-Visual Objects 2.0 installed

Version 2.0 and 2.5 of CA-Visual Objects can coexist on the same PC. They have to be installed in different directory trees. Important! Do not install CA-Visual Objects 2.5 in the same directory that holds your CA-Visual Objects 2.0 installation. This will destroy your CA-Visual Objects 2.0 installation and your CA-Visual Objects 2.0 repository. Even though version 2.5 and 2.0 can be installed on the same computer, they cannot be run at the same time.

Installing CA-Visual Objects 2.5 on a system that has CA-Visual Objects 1.0 installed

Version 1.0 and 2.5 of CA-Visual Objects can coexist on the same PC. They have to be installed in different directory trees. Important! Do not install CA-Visual Objects 2.5 in the same directory that holds your CA-Visual Objects 1.0 installation. This will destroy your CA-Visual Objects 1.0 installation and your CA-Visual Objects 1.0 repository.

Re-Installing CA-Visual Objects 2.5

Important!  Because it requires you to install a new repository, you must export your applications and libraries before re-installing.  Otherwise, your applications and libraries will be lost with no chance of recovery.  Please note that you should export your applications and libraries to another directory and then ERASE all files in your \CAVO25\Data directory.

Using different user accounts under Windows NT

The installation of CA-Visual Objects 2.5 requires Administrator rights under Windows NT. If you install CA-Visual Objects 2.5 with an Administrator account and plan to use it from another account later, it is important that you start CA-Visual Objects 2.5 once under the Administrator account used for installation before using CA-Visual Objects 2.5 from another account. If you fail to do so, you will lose all projects created using the other accounts when you log in under the original Administrator account used for installation and start CA-Visual Objects.

Once CA-Visual Objects 2.5 has been initialized properly by starting it once under the original Administrator account used for installation, it can be used from any number of different user accounts. All projects are shared among all accounts. Note:  Missing access rights under certain accounts may cause the product to fail.

Installing CA-Visual Objects

AutoStart Installation
	After Windows 9x or Windows NT has started, place the CA-Visual Objects CD-ROM in the CD-ROM drive.  Once this is done, the CA-Installer is automatically invoked.  Then follow the steps provided below under the Manual Installation instructions, skipping steps 1-3.

Manual Installation

To install CA-Visual Objects on your hard drive:
1.  Insert the CA-Visual Objects CD-ROM in the CD-ROM drive.
2.  Click the Start button and then click Run.
3.  In the Run dialog box, enter
cd-rom_drive:\setup
where cd-rom_drive represents the drive letter of the CD_ROM drive (for example, e:\setup).  Choose OK.
4.  A text window will display containing important information regarding the installation of CA-Visual Objects.  After reading this information, click OK to continue with the installation.
Note:  If you want to cancel the installation, this can be done in the Registration window.
5.  You will then be prompted with a message asking whether you want to view the Release Notes.  If you choose Yes, the Release Notes file for CA-Visual Objects will be displayed.  At this point you can read or print the Release Notes file.  This Release Notes file contains important information regarding the product and installation.  It is strongly recommended that you view this file.
6.  After the Release Notes file is closed, or if you choose No in step 5, the Registration window will display.  The Registration information is required in order to proceed with the installation.  Enter your name and your company name. Select OK to continue.
7.  A window will appear containing the default directory where CA-Visual Objects will be installed, C:\CAVO25.  You can specify another directory by typing in the full path.  Click Continue to proceed with the installation.
8.  The Selected Components Window will appear.

From here, you have two options.  You can either install all of the components that are part of the CA-Visual Objects package (i.e., the full installation) or select only those components you know you are going to need (i.e., a partial installation).

Full Installation
For the full installation, click on the Select All button and then choose Install.  The CA-Installer will begin the installation procedure; CA-Visual Objects will be installed in the drive and directory you specified.

Partial Installation
If you choose to selectively install CA-Visual Objects, you should first click on the Deselect All button and then proceed to click on only those components that you wish to install, or you can leave everything selected and click on only those components that you do not wish to include.  Either way, before you choose Install, the components that you want to install will be highlighted in the list box.

The various components are described below to help you decide what you need to install.  Note:  if you choose not to install a particular component at this time and later find that you need it, you can always run the CA-Installer again and select only that component without affecting the rest of your current installation.

Minimum Installation	The minimum installation must include Program Files and the System Repository.  This will install all the system-defined libraries as well as other components that are common to all applications.

Help Files	This option installs the online help file associated with CA-Visual Objects.  If you plan to use context-sensitive help, you must choose this option.

Application Wizard Files	This option installs the standard framework files needed for the Application Wizard and Application Gallery.  Choose this option if you plan on utilizing the standard framework files when generating applications or using the Application Gallery.

Sample Programs	This option installs the sample files that demonstrate various features and components of CA-Visual Objects.

Moving On

Once you have selected all of the components you wish to install, simply click on the Install button.  The CA-Installer will begin the installation procedure; CA-Visual Objects will be installed in the drive and directory you specified.

The CA-Visual Objects Folder

When the installation is complete, a folder will be created for CA-Visual Objects 2.5 and any other component installed.

Verify Temporary Directories

Before running CA-Visual Objects, verify that you have TEMP and TMP environment variables specifying a valid path.  These environment variables are used as part of the resource compilation process.  The path should not be on a network drive or in the root of a RAM disk.

Running CA-Visual Objects 2.5 on a dual boot Windows 9x / Windows NT system

If you have both Windows 9x and Windows NT installed on your PC and you want to run CA-Visual Objects 2.5 under both operating systems, please read this paragraph carefully.

CA-Visual Objects 2.5 stores its setup information in the system registry. Windows 9x and Windows NT maintain 2 different registries that are completely separate. Installing CA-Visual Objects 2.5 under one operating system will only setup the registry for the chosen operating system. Trying to start it under the other operating system will fail due to the lack of registry information.

The best way to get CA-Visual Objects 2.5 work on both operating systems is to do a clean install to the same directory under each operating system. This will ensure that you can access the Default Project from both operating systems. Do not create additional projects if you want to keep switching between operating systems!

You also might decide to install completely independent versions of CA-Visual Objects 2.5 into different directories. In this case do not try to share projects between the different versions.

Running CA-Visual Objects 2.5 applications

CA-Visual Objects 2.5 does not require a path setting for running applications from inside the IDE. It will make sure that the required runtime DLLs are found, regardless where the EXE is placed.  However, running EXEs that are not in the CAVO25\BIN directory requires a search path including CAVO25\BIN.  Setting this path is the user's responsibility.  Alternatively, the required runtime DLLs can be copied in the EXE directory (e.g., using the Install Maker).

___________________________________________________________________________

Using Jasmine with CA-Visual Objects 2.5

CA-Visual Objects 2.5 contains classes that allow you to incorporate Jasmine classes and objects into your applications. Jasmine is Computer Associates intelligent information infrastructure and pure object database. To take advantage of these features, you will need to have Jasmine installed on your machine.

For more information on Jasmine and to order the Free Developer Edition Jasmine CD, please visit the Computer Associates website at www.cai.com.

To see CA-Visual Objects and Jasmine in action, import one of the 3 Jasmine sample applications located in the CAVO25\Samples\Jasmine subdirectory.
___________________________________________________________________________

Trial Version Limitations

As a free trial version, there are some limitations to the features of a CA-Visual Objects 2.5 Trial version installation:

* No SQL Classes or SQL Editor 
The Trial version of CA-Visual Objects only allows DBF access through the native RDD drivers (DBFNTX, DBFCDX, and DBFMDX).  The full version of CA-Visual Objects 2.5 provides both SQL Classes and an SQL Editor for access to many popular SQL engines through ODBC drivers, including MS SQL Server, Oracle, and CA-OpenIngres.

* RDDs limit size of DBFs to 400 records
The Trial version of CA-Visual Objects limits the number of records that a database file (.DBF) can contain to 400 records.  If you attempt to open a database containing more than 400 records, you will receive a runtime error.

* No Report Classes or Report Editor
The Trial version of CA-Visual Objects does not provide a facility for automatically generating reports.  The full version of CA-Visual Objects 2.5 provides both Report Classes and a Report Editor for generating and manipulating reports.  This allows for generation of tabular, form, label, letter, free style, and cross tabular reports to summarize information for databases (DBF or SQL) used in your applications. 

* No Microsoft Common Source Control API Interface
The Trial version of CA-Visual Objects does not provide support for the Microsoft Common Source Code Control API.  The full version of CA-Visual Objects 2.5 has the Microsoft Common Source Code Control API Interface built in, which allows products like Microsoft Visual Source Safe to be used for source code management and multiple-programmer support.

* No EXE Generation
You can freely create applications with the Trial version of CA-Visual Objects 2.5 and run those applications from the IDE.  However, you cannot generate executables for those applications.  Note that any application created with the Trial version can be exported to an Application Export File (.AEF) and later imported back into CA-Visual Objects 2.5 (either the Trial version or the full version).

* No DLL Generation
Just like executables, the Trial version of CA-Visual Objects will not permit the generation of dynamically linked libraries (DLLs).  You can, however, export any DLL application to a .AEF file and later import those files back into CA-Visual Objects 2.5 (either the Trial version or the full version).

Note:  Due to the EXE and DLL generation limitations, it is not possible to generate OLE Automation Servers or ActiveX controls in the Trial version of CA-Visual Objects 2.5.  However, the full version of CA-Visual Objects 2.5 does allow the generation of OLE Automation Servers and ActiveX controls.  For example code for OLE Automation Servers or ActiveX controls, please take a look at the samples located in the CAVO25\Samples\OLE subdirectory.

___________________________________________________________________________

New Features and Improvements

A list of new libraries, additions to existing classes, and new classes, methods and functions is included in The New Features Guide, part of the online documentation included in the full version of CA-Visual Objects.
___________________________________________________________________________

Nation Modules

Nation modules for a variety of languages are included with the full version of CA-Visual Objects. These modules allow for nation-specific collation and indexing schemes when dealing with international databases.  
___________________________________________________________________________

CompuServe Facilities

There is a production CompuServe forum (GO CAVO25) targeted specifically for CA-Visual Objects.  Computer Associates will use this forum to communicate information regarding updates, fixes, and so on.

___________________________________________________________________________

Operating Systems

CA-Visual Objects release 2.5 currently supports MS-Windows 9x and MS-Windows NT.

___________________________________________________________________________

Ordering Information

There are 3 different CA-Visual Objects 2.5 packages, depending on whether you've owned a previous version of CA-Visual Objects.  

* CA-Visual Objects 2.5 Professional Upgrade
If you own CA-Visual Objects 1.0 Full or 2.0 Professional, then you qualify for the CA-Visual Objects 2.5 Professional Upgrade.  This upgrade verifies that a previous Full/Professional version of CA-Visual Objects 1.0 or 2.0 is installed on your machine, and if so, installs the full CA-Visual Objects 2.5.

* CA-Visual Objects 2.5 Standard Upgrade
If you own CA-Visual Objects 1.0 Lite or 2.0 Standard, then you qualify for the CA-Visual Objects 2.5 Standard Upgrade.  This upgrade verifies that the previous Lite/Standard version of CA-Visual Objects 1.0 or 2.0 is installed on your machine, and if so, installs the full CA-Visual Objects 2.5.

* CA-Visual Objects 2.5 Full Product
If you have never owned CA-Visual Objects before, then you will need to purchase the CA-Visual Objects 2.5 Full Product installation.

Note:  Installation of any of these 3 packages results in the same CA-Visual Objects Workgroup installation.  There is no functional difference between the resultant installation of these 3 packages.

To order any of the CA-Visual Objects 2.5 packages in the US or Canada, please call the CA Product Order Desk at 1-800-841-8743, or contact one of the CA-Visual Objects resellers.  A list can be found on the CA-Visual Objects web page on www.cai.com.  (Select "Products", then CA-Visual Objects.)

To order any of the CA-Visual Objects 2.5 packages in any other country, please contact your local CA office (click on "CA Worldwide Offices & Events" under the CAI Web at www.cai.com), your designated local reseller, or one of the CA-Visual Objects resellers listed on the CA-Visual Objects web page (see above).
___________________________________________________________________________

Acknowledgements

Portions of this software are based in part on the work of the Independent JPEG Group.


Copyright (c) 1994 - 1999 Computer Associates International, Inc.
All product names mentioned herein are trademarks of their respective companies.

