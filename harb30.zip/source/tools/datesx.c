/*
 * $Id: datesx.c,v 1.5 1999/07/29 03:40:48 vszel Exp $
 */

#include "extend.h"
#include <time.h>

HARBOUR HB_DATETIME( void )
{
   time_t current_time;
   char * szResult = ( char * ) hb_xgrab( 26 );

   time( &current_time );

   szResult = strcpy( szResult, ctime( &current_time ) );

   hb_retc( szResult );
   hb_xfree( szResult );
}

